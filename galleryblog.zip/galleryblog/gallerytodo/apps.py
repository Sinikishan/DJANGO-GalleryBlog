from django.apps import AppConfig


class GallerytodoConfig(AppConfig):
    name = 'gallerytodo'

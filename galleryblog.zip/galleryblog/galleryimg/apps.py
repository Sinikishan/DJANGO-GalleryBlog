from django.apps import AppConfig


class GalleryimgConfig(AppConfig):
    name = 'galleryimg'
